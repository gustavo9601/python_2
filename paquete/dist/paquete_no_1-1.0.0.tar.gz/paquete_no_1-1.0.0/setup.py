from setuptools import setup

setup(
    name="paquete_no_1",
    version="1.0.0",
    description="Documentacion de paquete_1",
    author="GM",
    author_email = "ing.gustavo.marquez@gmail.com",
    scripts=[], # en el arreglo se pasa el nombre de los scrripts de necesitarse
    packages=["paquete_1"]  # se pasa el paquete (directorio), paquete.direcotiro hijo etc
)

